1.0.3 / 2018-09-12
==================

  * perf: enable strict mode

1.0.2 / 2017-08-26
==================

  * perf: improve comparison speed

1.0.1 / 2014-05-07
==================

  * Readme changes
  * Update repository for organization move

1.0.0 / 2013-12-21
==================

  * Remove default key generation and associated expectations
